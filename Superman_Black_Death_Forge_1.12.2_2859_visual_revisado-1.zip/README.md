# Superman Black Death — Forge 1.12.2

Projeto-fonte para Minecraft Java 1.12.2 / Forge 14.23.5.2859.

## Conteúdo
- Traje completo: Capacete, Peitoral, Calça e Botas.
- Poderes só são ativados com as quatro peças equipadas.
- Voo estilo criativo (incluindo sobrevivência), super força x10, velocidade, salto alto,
  regeneração, resistência a dano, visão de calor (R), sopro congelante (G),
  visão de raio-X aproximada (X), Modo Morte Negra (V) e teleporte (Shift+Espaço duas vezes).
- Partículas escuras enquanto o traje está completo.
- Receitas caras com ferro, diamante, ouro, obsidiana, pérola do End e Nether Star.

## Receitas
As receitas estão em `SupermanBlackDeath.java`. O peitoral exige Nether Star no centro.
As demais receitas usam diamante, obsidiana, ouro e pérolas do End.

## Compilar
1. Instale Java 8.
2. Baixe o Forge MDK `1.12.2-14.23.5.2859`.
3. Copie do MDK os arquivos `gradlew`, `gradlew.bat` e a pasta `gradle/` para esta pasta.
4. Execute `gradlew build`.
5. O JAR será criado em `build/libs/SupermanBlackDeath-1.0.0.jar`.
6. Coloque o JAR na pasta `mods` com Forge 1.12.2.

## Controles
- R: Visão de Calor
- G: Sopro Congelante
- X: Visão de Raio-X (marcadores temporários de minérios próximos e mobs brilhando)
- V: Modo Morte Negra
- Shift + Espaço duas vezes rapidamente: Teleporte Sombra

## Observações técnicas
- É um projeto-fonte; não inclui JAR compilado.
- O voo é concedido por `allowFlying` enquanto o conjunto está equipado.
- O efeito de raio-X marca mobs com brilho e cria partículas nos minérios próximos; não substitui um shader/renderizador de raio-X completo.
- A capa e o emblema são representados nas texturas de armadura; o sistema padrão de armadura 1.12.2 não oferece uma capa 3D animada personalizada.
- Os efeitos de combate são mecânicas de jogo fictícias.


## Aparência revisada conforme a referência enviada
O traje foi atualizado para preto/carvão quase inteiramente, com visor vermelho, detalhes vermelhos discretos e emblema cinza escuro nas costas. Não usa azul nem capa vermelha, seguindo a skin de referência. As texturas são uma adaptação para as camadas de armadura do Minecraft 1.12.2.
