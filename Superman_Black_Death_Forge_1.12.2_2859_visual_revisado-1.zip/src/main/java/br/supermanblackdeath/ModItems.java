package br.supermanblackdeath;

import java.util.Arrays;
import java.util.List;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.util.ResourceLocation;

public final class ModItems {
    public static final Item HELMET = armor("capacete", EntityEquipmentSlot.HEAD, 0);
    public static final Item CHEST = armor("peitoral", EntityEquipmentSlot.CHEST, 1);
    public static final Item LEGS = armor("calca", EntityEquipmentSlot.LEGS, 2);
    public static final Item BOOTS = armor("botas", EntityEquipmentSlot.FEET, 3);
    public static final List<Item> ALL = Arrays.asList(HELMET,CHEST,LEGS,BOOTS);

    private static Item armor(String name, EntityEquipmentSlot slot, int renderIndex) {
        ItemArmor item = new ItemArmor(SupermanBlackDeath.MATERIAL, renderIndex, slot);
        item.setRegistryName(new ResourceLocation(SupermanBlackDeath.MODID,name));
        item.setUnlocalizedName(SupermanBlackDeath.MODID+"."+name);
        item.setCreativeTab(SupermanBlackDeath.TAB);
        return item;
    }
    public static void register() { }
}
