package br.supermanblackdeath;

import java.util.List;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class ArmorPowers {
    public static boolean hasFullSuit(EntityPlayer p) {
        return p.getItemStackFromSlot(net.minecraft.inventory.EntityEquipmentSlot.HEAD).getItem()==ModItems.HELMET &&
               p.getItemStackFromSlot(net.minecraft.inventory.EntityEquipmentSlot.CHEST).getItem()==ModItems.CHEST &&
               p.getItemStackFromSlot(net.minecraft.inventory.EntityEquipmentSlot.LEGS).getItem()==ModItems.LEGS &&
               p.getItemStackFromSlot(net.minecraft.inventory.EntityEquipmentSlot.FEET).getItem()==ModItems.BOOTS;
    }

    @SubscribeEvent public static void tick(LivingEvent.LivingUpdateEvent e) {
        if (!(e.getEntityLiving() instanceof EntityPlayer)) return;
        EntityPlayer p=(EntityPlayer)e.getEntityLiving();
        if (p.world.isRemote) return;
        if (!hasFullSuit(p)) {
            if (p.getEntityData().getBoolean("sbd_flight")) {
                p.getEntityData().removeTag("sbd_flight");
                if (!p.capabilities.isCreative && !p.capabilities.isSpectator) {
                    p.capabilities.isFlying=false;
                    p.capabilities.allowFlying=false;
                    p.sendPlayerAbilities();
                }
            }
            return;
        }
        p.fallDistance=0;
        p.addPotionEffect(new PotionEffect(MobEffects.REGENERATION,100,3,true,false));
        p.addPotionEffect(new PotionEffect(MobEffects.SPEED,100,3,true,false));
        p.addPotionEffect(new PotionEffect(MobEffects.JUMP_BOOST,100,4,true,false));
        p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE,100,4,true,false));
        p.addPotionEffect(new PotionEffect(MobEffects.FIRE_RESISTANCE,100,0,true,false));
        p.addPotionEffect(new PotionEffect(MobEffects.WATER_BREATHING,100,0,true,false));
        if (p.ticksExisted%8==0) {
            for(int i=0;i<5;i++) p.world.spawnParticle(EnumParticleTypes.SMOKE_NORMAL,
                p.posX+(p.getRNG().nextDouble()-.5)*1.4,p.posY+p.getRNG().nextDouble()*2.0,
                p.posZ+(p.getRNG().nextDouble()-.5)*1.4,0,0.015,0);
        }
        // Survival flight; creative flight remains vanilla-controlled.
        if (!p.capabilities.allowFlying && !p.capabilities.isCreative && !p.capabilities.isSpectator) {
            p.capabilities.allowFlying=true;
            p.getEntityData().setBoolean("sbd_flight",true);
            p.sendPlayerAbilities();
        }
        p.getFoodStats().setFoodLevel(20);
    }

    @SubscribeEvent public static void hurt(LivingHurtEvent e) {
        if (e.getSource().getTrueSource() instanceof EntityPlayer) {
            EntityPlayer p=(EntityPlayer)e.getSource().getTrueSource();
            if (hasFullSuit(p)) e.setAmount(e.getAmount()*10.0F);
        }
    }
    @SubscribeEvent public static void breakSpeed(PlayerEvent.BreakSpeed e) {
        if (hasFullSuit(e.getEntityPlayer())) e.setNewSpeed(e.getNewSpeed()*12.0F);
    }
    @SubscribeEvent public static void fall(LivingFallEvent e) {
        if (e.getEntityLiving() instanceof EntityPlayer && hasFullSuit((EntityPlayer)e.getEntityLiving())) e.setCanceled(true);
    }
    @SubscribeEvent public static void attack(LivingAttackEvent e) {
        if (e.getEntityLiving() instanceof EntityPlayer && hasFullSuit((EntityPlayer)e.getEntityLiving())) {
            String type=e.getSource().getDamageType();
            if (!"outOfWorld".equals(type)) e.setCanceled(true);
        }
    }

    public static void heatVision(EntityPlayerMP p) {
        Vec3d start=p.getPositionEyes(1.0F);
        Vec3d look=p.getLook(1.0F);
        Vec3d end=start.add(look.scale(30));
        for(int i=1;i<=30;i++) {
            Vec3d point=start.add(look.scale(i));
            p.world.spawnParticle(EnumParticleTypes.FLAME,point.x,point.y,point.z,0,0,0,0,2);
        }
        EntityLivingBase target=rayTarget(p,30,1.4);
        if(target!=null) { target.setFire(5); target.attackEntityFrom(net.minecraft.util.DamageSource.causePlayerDamage(p),14.0F); }
    }

    public static void freezeBreath(EntityPlayerMP p) {
        Vec3d start=p.getPositionEyes(1.0F), look=p.getLook(1.0F);
        for(int i=1;i<=12;i++) {
            Vec3d point=start.add(look.scale(i));
            BlockPos pos=new BlockPos(point);
            IBlockState state=p.world.getBlockState(pos);
            if(state.getBlock()==Blocks.WATER || state.getBlock()==Blocks.FLOWING_WATER) {
                p.world.setBlockState(pos,Blocks.ICE.getDefaultState(),3);
            }
            p.world.spawnParticle(EnumParticleTypes.SNOWBALL,point.x,point.y,point.z,0,0,0,0,2);
        }
        for(EntityLivingBase mob:p.world.getEntitiesWithinAABB(EntityLivingBase.class,p.getEntityBoundingBox().grow(8,4,8))) {
            if(mob!=p && mob.getDistance(p)<9 && p.getLookVec().dotProduct(mob.getPositionVector().subtract(p.getPositionVector()).normalize())>0.45)
                mob.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS,100,3));
        }
    }

    public static void xray(EntityPlayerMP p) {
        p.addPotionEffect(new PotionEffect(MobEffects.NIGHT_VISION,220,0,true,false));
        for(EntityLivingBase mob:p.world.getEntitiesWithinAABB(EntityLivingBase.class,p.getEntityBoundingBox().grow(32))) {
            if(mob!=p) mob.addPotionEffect(new PotionEffect(MobEffects.GLOWING,200,0,true,false));
        }
        // Brief particle markers on nearby common ore blocks.
        for(BlockPos pos:BlockPos.getAllInBox(p.getPosition().add(-12,-8,-12),p.getPosition().add(12,8,12))) {
            net.minecraft.block.Block b=p.world.getBlockState(pos).getBlock();
            if(b==Blocks.DIAMOND_ORE || b==Blocks.GOLD_ORE || b==Blocks.IRON_ORE || b==Blocks.EMERALD_ORE || b==Blocks.REDSTONE_ORE || b==Blocks.LAPIS_ORE) {
                p.world.spawnParticle(EnumParticleTypes.CRIT_MAGIC,pos.getX()+.5,pos.getY()+.5,pos.getZ()+.5,0,0,0,0,5);
            }
        }
    }

    public static void deathMode(EntityPlayerMP p) {
        p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH,600,19,true,false));
        p.addPotionEffect(new PotionEffect(MobEffects.REGENERATION,600,4,true,false));
        p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE,600,4,true,false));
        for(EntityLivingBase mob:p.world.getEntitiesWithinAABB(EntityLivingBase.class,p.getEntityBoundingBox().grow(15))) {
            if(mob!=p) mob.addPotionEffect(new PotionEffect(MobEffects.WITHER,600,1));
        }
        for(int i=0;i<80;i++) p.world.spawnParticle(EnumParticleTypes.SMOKE_LARGE,p.posX+(p.getRNG().nextDouble()-.5)*4,p.posY+p.getRNG().nextDouble()*2,p.posZ+(p.getRNG().nextDouble()-.5)*4,0,.03,0);
    }

    public static void shadowTeleport(EntityPlayerMP p) {
        Vec3d start=p.getPositionEyes(1), look=p.getLook(1);
        for(int i=20;i>=1;i--) {
            Vec3d v=start.add(look.scale(i));
            BlockPos feet=new BlockPos(v.x,p.posY,v.z);
            if(p.world.isAirBlock(feet) && p.world.isAirBlock(feet.up()) && p.world.getBlockState(feet.down()).isTopSolid()) {
                p.connection.setPlayerLocation(v.x,feet.getY(),v.z,p.rotationYaw,p.rotationPitch);
                for(int n=0;n<30;n++) p.world.spawnParticle(EnumParticleTypes.SMOKE_LARGE,p.posX,p.posY+1,p.posZ,0,.02,0);
                return;
            }
        }
    }

    private static EntityLivingBase rayTarget(EntityPlayer p,double range,double radius) {
        Vec3d start=p.getPositionEyes(1), look=p.getLook(1), end=start.add(look.scale(range));
        EntityLivingBase best=null; double bestDist=range+1;
        for(EntityLivingBase e:p.world.getEntitiesWithinAABB(EntityLivingBase.class,p.getEntityBoundingBox().grow(range))) {
            if(e==p) continue;
            net.minecraft.util.math.AxisAlignedBB box=e.getEntityBoundingBox().grow(radius);
            RayTraceResult hit=box.calculateIntercept(start,end);
            if(hit!=null) {
                double dist=start.distanceTo(hit.hitVec);
                if(dist<bestDist) {best=e;bestDist=dist;}
            }
        }
        return best;
    }
}
