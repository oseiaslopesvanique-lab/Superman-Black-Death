package br.supermanblackdeath;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;

@SideOnly(Side.CLIENT)
public class ClientProxy {
    private static KeyBinding heat, freeze, xray, death;
    private static boolean spaceWasDown=false;
    private static long lastTeleport=0;

    public static void register() {
        heat=new KeyBinding("key.blackdeath.heat",Keyboard.KEY_R,"key.categories.blackdeath");
        freeze=new KeyBinding("key.blackdeath.freeze",Keyboard.KEY_G,"key.categories.blackdeath");
        xray=new KeyBinding("key.blackdeath.xray",Keyboard.KEY_X,"key.categories.blackdeath");
        death=new KeyBinding("key.blackdeath.death",Keyboard.KEY_V,"key.categories.blackdeath");
        ClientRegistry.registerKeyBinding(heat); ClientRegistry.registerKeyBinding(freeze);
        ClientRegistry.registerKeyBinding(xray); ClientRegistry.registerKeyBinding(death);
        FMLCommonHandler.instance().bus().register(new ClientProxy());
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent event) {
        if (heat.isPressed()) send(PowerPacket.HEAT);
        if (freeze.isPressed()) send(PowerPacket.FREEZE);
        if (xray.isPressed()) send(PowerPacket.XRAY);
        if (death.isPressed()) send(PowerPacket.DEATH);
        if (net.minecraft.client.Minecraft.getMinecraft().player != null) {
            boolean space=Keyboard.isKeyDown(Keyboard.KEY_SPACE);
            boolean shift=Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) || Keyboard.isKeyDown(Keyboard.KEY_RSHIFT);
            long now=System.currentTimeMillis();
            if (space && shift && !spaceWasDown) {
                if (now-lastTeleport < 450) { send(PowerPacket.TELEPORT); lastTeleport=0; }
                else lastTeleport=now;
            }
            spaceWasDown=space && shift;
        }
    }
    private void send(int action) {
        if (net.minecraft.client.Minecraft.getMinecraft().player != null)
            SupermanBlackDeath.NETWORK.sendToServer(new PowerPacket(action));
    }
}
