package br.supermanblackdeath;
public class CommonProxy { public void register() {} }
