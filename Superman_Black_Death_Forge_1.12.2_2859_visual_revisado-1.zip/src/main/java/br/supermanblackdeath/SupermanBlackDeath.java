package br.supermanblackdeath;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraft.util.ResourceLocation;

@Mod(modid=SupermanBlackDeath.MODID, name=SupermanBlackDeath.NAME, version=SupermanBlackDeath.VERSION)
@EventBusSubscriber
public class SupermanBlackDeath {
    public static final String MODID="supermanblackdeath";
    public static final String NAME="Superman Black Death";
    public static final String VERSION="1.0.0";
    public static final CreativeTabs TAB = new CreativeTabs("supermanblackdeath") {
        @Override public Item getTabIconItem() { return ModItems.CHEST; }
    };
    public static final ItemArmor.ArmorMaterial MATERIAL =
        EnumHelper.addArmorMaterial("BLACK_DEATH", MODID+":black_death", 66,
            new int[]{4,9,7,4}, 25, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 4.0F);

    public static SimpleNetworkWrapper NETWORK;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        NETWORK = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);
        NETWORK.registerMessage(PowerPacket.Handler.class, PowerPacket.class, 0, Side.SERVER);
        ModItems.register();
        if (event.getSide().isClient()) ClientProxy.register();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        GameRegistry.addRecipe(new net.minecraft.item.ItemStack(ModItems.HELMET),
            "DOD","E E",'D',net.minecraft.init.Items.DIAMOND,'O',net.minecraft.init.Items.OBSIDIAN,'E',net.minecraft.init.Items.ENDER_PEARL);
        GameRegistry.addRecipe(new net.minecraft.item.ItemStack(ModItems.CHEST),
            "DOD","GNG","DOD",'D',net.minecraft.init.Items.DIAMOND,'O',net.minecraft.init.Items.OBSIDIAN,
            'G',net.minecraft.init.Items.GOLD_INGOT,'N',net.minecraft.init.Items.NETHER_STAR);
        GameRegistry.addRecipe(new net.minecraft.item.ItemStack(ModItems.LEGS),
            "DOD","E E","G G",'D',net.minecraft.init.Items.DIAMOND,'O',net.minecraft.init.Items.OBSIDIAN,
            'E',net.minecraft.init.Items.ENDER_PEARL,'G',net.minecraft.init.Items.GOLD_INGOT);
        GameRegistry.addRecipe(new net.minecraft.item.ItemStack(ModItems.BOOTS),
            "E E","DOD","G G",'E',net.minecraft.init.Items.ENDER_PEARL,'D',net.minecraft.init.Items.DIAMOND,
            'O',net.minecraft.init.Items.OBSIDIAN,'G',net.minecraft.init.Items.GOLD_INGOT);
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        for (Item item : ModItems.ALL) event.getRegistry().register(item);
    }
}
