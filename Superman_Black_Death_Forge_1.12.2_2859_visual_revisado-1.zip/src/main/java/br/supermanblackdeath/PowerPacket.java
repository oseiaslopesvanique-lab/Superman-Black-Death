package br.supermanblackdeath;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.common.FMLCommonHandler;

public class PowerPacket implements IMessage {
    public static final int HEAT=0, FREEZE=1, XRAY=2, DEATH=3, TELEPORT=4;
    private int action;
    public PowerPacket() {}
    public PowerPacket(int action) { this.action=action; }
    @Override public void toBytes(ByteBuf buf) { buf.writeInt(action); }
    @Override public void fromBytes(ByteBuf buf) { action=buf.readInt(); }

    public static class Handler implements IMessageHandler<PowerPacket,IMessage> {
        @Override public IMessage onMessage(final PowerPacket message, final MessageContext ctx) {
            final EntityPlayerMP player=ctx.getServerHandler().player;
            FMLCommonHandler.instance().getMinecraftServerInstance().addScheduledTask(() -> {
                if (!ArmorPowers.hasFullSuit(player)) return;
                switch(message.action) {
                    case HEAT: ArmorPowers.heatVision(player); break;
                    case FREEZE: ArmorPowers.freezeBreath(player); break;
                    case XRAY: ArmorPowers.xray(player); break;
                    case DEATH: ArmorPowers.deathMode(player); break;
                    case TELEPORT: ArmorPowers.shadowTeleport(player); break;
                }
            });
            return null;
        }
    }
}
